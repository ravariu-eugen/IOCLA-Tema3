#ifndef __POSITIONS_H__
#define __POSITIONS_H__

#define FIRST_POSITION	2
#define FIRST_VALUE	10
#define SECOND_POSITION	4
#define SECOND_VALUE	127
#define THIRD_POSITION	7
#define THIRD_VALUE	21

#endif /* __POSITIONS_H__ */
